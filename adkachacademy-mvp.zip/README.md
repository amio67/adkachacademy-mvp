# AdkachAcademy Pro - MVP LMS

Ce projet est un MVP d'une plateforme LMS avec les fonctionnalités suivantes :
- Authentification (JWT)
- Gestion des utilisateurs (étudiant, formateur)
- Création et consultation de cours
- Inscription et progression
- Backend : Node.js + Express + MongoDB
- Frontend : React.js (Vite) + Tailwind CSS